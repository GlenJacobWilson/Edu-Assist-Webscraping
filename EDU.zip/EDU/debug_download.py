import requests
import json
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# --- CONFIGURATION ---
FILE_ID = "AAAbHw=="  # This is the ID from your previous message
URL = "https://api.ktu.edu.in/ktu-web-portal-api/anon/getAttachment"

# PASTE YOUR NEW TOKEN HERE
TOKEN = 'G4s=======0cAFcWeA6YqWCiYkVxjtX9yEvU7kIz-5uSyRte4Suge_D5hIR3klpsg5fIUq9hLLCfO1bZYCLoYeuOEaMh8Rgyop2zwqMiBVDCBc5VA6igy7Qg2U19M2H9Dn4fu5lXJEPiuBZ19Hv2gvgl8jVveg45_-PMkgqPmKPgtSvyJE5AXjqhrx_PhfQs4vEI4v0O1LCxvWmmC0db1gJfj_RSnQIM1sBQP0YMMcW0024bzBFrjMtnui_kVWo6uCNYyB8lfbIR3JFkjamqjAdffDxt2_04UPAYSMGqNHqEO9IQcRbCn11bpu5Liz2WdAzBlP71ttAebkwl1krIXPUeMunTpe0Et5af32yiAjaf41pOCtcIPCvCfv7tZcnrPc_zU7eEAF_WQ4tFYYDE-0FuEstF5liU_OzTv11-8rRaiYiyBXORIoANadW6pPfaCrFtxk15LxeiPo6InQiTv0YH3O00rhQero87rBD9dV9CyB_RvqFThJajaO2GruMZ0ZvyYCZM0d_lLEwsDGaX2h4gX6n3s2_46lbifoopmTBIueRWm96wK5rR_XBPf34lbz7iqROV0U9bBQ5Dx7LlTQ49bd60z1-5igumXjvkr4ealp4vGFMTXmttMpMxSTuVrcR3jxkOHjuTjastxyHwO4PnG8a0kBaRVw6DUAyLSDaiE_uBP4RMNUXdlkK-PECo1LJZl9Z3Y8mngleejt9uZjmaVYuCg7CJUf3RwBhkFqAHSv3Gd0nY-fKQbTpgpYGEXGZFS7MR6XwBlMVHrHdPeYwUpc9vbSBvudY1KCKpJujVdUkORe4c-zI0qIwPIHfc3rcq43XsofDcGM7avyH4DqyCCFg8NHIKL-kTdQXa_V2fj_A8HpmshZo__JaJadLAG-j6_H9gCco8viU2G0YwmzIdNhbgiVnQ_cO7IEiXKGWO0CBdURC1Nd1fyv3VEP-GWx4LnEYh0p4IACfNMRC3i0GB7aYVT40V_bUF9cQqa1e7ZWtUqFAgVi5k4CE4cRuiusMKIczHraA6nvCuQciSEv_vZZCoDsBUwOLxdDqKopGyg7MH2_46EJ0HQbYOMSLlYsrzfhTumIK6Mjgpu6f7FFMbXC0uIV94eD6upkogissrz1jUXqJUUlBVf9SKYx56KXQbpdgqihvfFB7ZP09kjGYg1hg-kUSKEBZua_htTBJXI0h1vQnKjWvYvoPNDvz2I6odhWQLpGuZgg3zFrZo9XCp3iLB10Vipme9-3MtJrmCHdp6uUsiUp2RtzKTqLn7RLgyjtaEDXo42LxqQmBwple9NAP0UDac2u0YeVUMNIklLeunJY85qxxEexXayJhP7W-nB9mzlKG1kEO3j58ncnaZByOQTHOQYGPSF8UJuFu89ZiVeVM89b9z5Dr95jxXUFooz-QUm0j1Gthw01YYpeNxdhkiOPdYpxv5uGYIeUBwtLpKntNJuoThSyzmXAa_nh3jQ_EDUUnHpckKehEh6oWEcPIbGuPJpGFsdLvAKPNR4lbKuOeSXTkLOvlANhy_4vH4ceAOt9QeFpKcAVfgPUW073YPlxckvTnPhX74Txfxbh8Jct3YmAytYKZLoLo7n_UDmufkWoHNSjlwZnLrRBtplTpBk1_XudbF6LjnKWa-OlQ4lnvrGWmd8ein6g8Hkz8wld8NMHZ9v-XXWSDKxBZkA_5mIFvdty0wCCWteu9Q4EqPO-6z6WWR9nsakWyUJHyINqr6uhnoTIBTVArsCGsHdIKfD6FfutVWE-JS_2ZZ78u_SyJ6p8RzYV4xQ030YKL17MhctTkW-l3LGdkykAFY9CedfZ9QULM50DNJQWk97hEfc--DsYIPbi5vCuYXWS6MzCPqJWcN6FC0c7C9yS6p31vmzocZh166sXAXY1sAS2VxkXhq0RTiu8ixNgdmxLBLE-flyXd3pfTklPGFcNMrOJ0JkZiWngA-JFcQ7g6kqdo0-MFuugjzHweK-Im6iBB8uERQSzldv0kcYXeXTG_1pD_TA189goa_gnCZbZHj8cSSFf1DKh3uDK2FUlbKcxTU17OfvVrqdlk0gUg010tgv28VLrer8H2j12bnOgZvHzGr9gz0F-jL4oqS4xMZ0T0EUaHzGamUiqKQzw3vsxLmxYS4T15G0TVhHUIHTdTxBHXJA9hzTjc7qNuv9RKT6MEw5jMdFVpcB2F4ozR334JZUFIWCjEE39oCkNBLY_zQfGubVIrAqMXgbXO2pXp_CwlkE2cacGv_W0IPdJw1LmpZH7GUQvuv3lo++6LfKyPAqAAAAAGBsUvD6QfSnqOyFFuzzVxT3s9dx' 

headers = {
    'Accept': 'application/json, text/plain, */*',
    'Content-Type': 'application/json',
    'Origin': 'https://ktu.edu.in',
    'Referer': 'https://ktu.edu.in/',
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36',
    'x-Token': TOKEN
}

payload = {'encryptId': FILE_ID}

print(f"--- ATTEMPTING DOWNLOAD FOR ID: {FILE_ID} ---")
try:
    response = requests.post(URL, headers=headers, json=payload, verify=False)
    
    print(f"STATUS CODE: {response.status_code}")
    
    if response.status_code == 200:
        print("\n--- SUCCESS! INSPECTING DATA ---")
        try:
            data = response.json()
            print("Response is JSON.")
            print("KEYS FOUND:", list(data.keys()))
            
            # Check for common keys
            if 'dataBytes' in data:
                print("✅ Found 'dataBytes' key! (Length:", len(data['dataBytes']), ")")
            elif 'fileContent' in data:
                print("✅ Found 'fileContent' key!")
            else:
                print("❌ 'dataBytes' NOT found. The keys are:", list(data.keys()))
        except:
            print("Response is NOT JSON. First 100 chars:")
            print(response.text[:100])
    else:
        print("\n--- FAILED ---")
        print("Server Response:", response.text)
        
except Exception as e:
    print(f"CRITICAL ERROR: {e}")